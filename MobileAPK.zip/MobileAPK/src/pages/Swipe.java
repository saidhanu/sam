package pages;

import java.time.Duration;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class Swipe {
	

	//Property
	public AndroidDriver driver;
	
	//locator elements

	@FindBy(xpath = "(//android.view.ViewGroup[@content-desc=\"card\"])[1]")
	public WebElement card1;
	
	@FindBy(xpath = "(//android.view.ViewGroup[@content-desc=\"card\"])[2]")
	public WebElement card2;
	
	@FindBy(xpath = "(//android.view.ViewGroup[@content-desc=\"card\"])[3]")
	public WebElement card3;
	
	@FindBy(xpath = "(//android.view.ViewGroup[@content-desc=\"card\"])[4]")
	public WebElement card4;
	
	@FindBy(xpath = "(//android.view.ViewGroup[@content-desc=\"card\"])[5]")
	public WebElement card5;

	//method-constructor method
	
		public Swipe(AndroidDriver driver) {
			
			this.driver = driver;
			PageFactory.initElements(driver,this);
		}
		
		public void swipe1() {
			
//			TouchAction action = new TouchAction(driver);
//
//	        int startY = card1.getLocation().getY() + (card1.getSize().getHeight() / 2);
//	        int startX = card1.getLocation().getX() + (card1.getSize().getWidth() / 2);
//
//	        int endX = card2.getLocation().getX() + (card2.getSize().getWidth() / 2);
//	        int endY = card2.getLocation().getY() + (card2.getSize().getHeight() / 2);
//
//	        //action.press(startX, startY).waitAction(2000).moveTo(endX, endY).release().perform();
//	        action.press(startX, startY).waitAction(((Object) WaitOptions.waitOptions(Duration.ofMillis(1300))).moveTo(endX,
//	        		endY).release().perform();
//	        action.press(PointOption.point(427, 878)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(1300)).moveTo(PointOption.point(427, 554)).release().perform();
//			
//			TouchActions action = new TouchActions(driver);
//			action.scroll(card1, 10, 100);
//			action.perform();
//			WebElement slider =  driver.findElement(By.xpath("//window[1]/slider[1]"));
			card1.sendKeys("0.5");
}

}
//Dimension size = driver.manage().window().getSize();
//
//int startX = 0;
//int endX = 0;
//int startY = 0;
//int endY = 0;
//
//switch (direction) {
//    case RIGHT:
//        startY = (int) (size.height / 2);
//        startX = (int) (size.width * 0.90);
//        endX = (int) (size.width * 0.05);
//        new TouchAction(driver)
//                .press(startX, startY)
//                .waitAction(Duration.ofMillis(duration))
//                .moveTo(endX, startY)
//                .release()
//                .perform();
