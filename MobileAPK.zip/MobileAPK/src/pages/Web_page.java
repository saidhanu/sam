package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.android.AndroidDriver;

public class Web_page {
	
	//Property
		public AndroidDriver driver;
		
		//locator elements
		
		@FindBy(xpath = "//android.view.View[@content-desc=\"Copyright © 2020 OpenJS Foundation\"]")
		public WebElement cp;

}
