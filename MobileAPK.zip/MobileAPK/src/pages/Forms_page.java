package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.android.AndroidDriver;

public class Forms_page {
	
	//Property
	public static AndroidDriver driver;
	
	//locator elements
	
	@FindBy(xpath = "//android.widget.EditText[@content-desc=\"text-input\"]")
	public WebElement input;
	
	@FindBy(xpath = "//android.widget.Switch[@content-desc=\"switch\"]")
	public WebElement toggler;
	
	@FindBy(xpath = "//android.view.ViewGroup[@content-desc=\"select-Dropdown\"]")
	List<WebElement> d;
	
	
	@FindBy(xpath = "//android.view.ViewGroup[@content-desc=\"button-Active\"]/android.view.ViewGroup/android.widget.TextView")
	public WebElement button;
	
	//method-constructor method
	
	public Forms_page(AndroidDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver,this);
		
	}
	//methods -operational methods -
	
	

	public void inputtext(String x) throws Exception {
		
		input.click();
		Thread.sleep(3000);
		
		input.sendKeys("Test");
		
	}
	
	public void togglerA() throws Exception {
		
		toggler.click();
		Thread.sleep(3000);
		
	}
	public void dr() throws Exception {
		
		WebElement z = driver.findElement(By.xpath("hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.CheckedTextView[2]"));
		
		WebDriverWait wait = new WebDriverWait(driver, 3000);
		wait.until(ExpectedConditions.visibilityOf(z));
		z.click();
//		 d.click();
//		 Thread.sleep(3000);
//		Select select = new Select(d); 
//		select.selectByValue("2");
	}
public void bt(){
		
		button.click();
}

}


