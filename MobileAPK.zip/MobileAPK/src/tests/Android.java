package tests;

import java.awt.Dimension;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import pages.Forms_page;
import pages.Swipe;
import pages.Web_page;

public class Android {
	
	public static AndroidDriver driver;
	public  static Forms_page f;
	public static  Swipe s;
	public static  Web_page wp;
	
	
	
	
	public static void main(String [] args) throws Exception{
		
		
		//Launching the app on Emulator.
		DesiredCapabilities dc = new DesiredCapabilities();
		
		dc.setCapability(MobileCapabilityType.AUTOMATION_NAME, "Appium");	
		dc.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
		dc.setCapability(MobileCapabilityType.PLATFORM_VERSION, "8.1.0");
		dc.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Emulator");
		dc.setCapability(MobileCapabilityType.APP, "/Users/mac/Downloads/Android-NativeDemoApp-0.2.1.apk");
		
		URL url = new URL("http://127.0.0.1:4723/wd/hub");
		
		
		
		AndroidDriver<WebElement> driver= new AndroidDriver<WebElement>(url,dc);
		
		f = new Forms_page(driver);
		s = new Swipe(driver);
		
		//navigating to forms screen
		
		WebElement g=driver.findElement(By.xpath("//android.view.ViewGroup[@content-desc=\"Forms\"]/android.view.ViewGroup/android.widget.TextView"));
		
		g.click();
		
		Thread.sleep(3000);
		 
	//Submit forms
			
		
				
		f.inputtext("Test");
		f.togglerA();
		f.dr();
		WebElement i = driver.findElement(By.xpath("//android.view.ViewGroup[@content-desc=\"select-Dropdown\"]"));
		
		i.click();
		Thread.sleep(3000);
			
		Select select = new Select(i); 
		select.selectByValue("2");
		f.bt();
		
		//Navigating to Swipe screen
		
		WebElement ss= driver.findElement(By.xpath("//android.view.ViewGroup[@content-desc=\"Swipe\"]/android.view.ViewGroup/android.widget.TextView"));
		ss.click();
		
		
		
		WebElement slider1 = driver.findElement(By.xpath("(//android.view.ViewGroup[@content-desc=\"card\"])[1]"));
		
		WebElement slider2 = driver.findElement(By.xpath("(//android.view.ViewGroup[@content-desc=\"card\"])[2]"));
		TouchActions action = new TouchActions(driver);

		((Object) TouchAction()).press(slider1).moveTo(slider2).release();
	
				
		
		
	}




	}




	
	


